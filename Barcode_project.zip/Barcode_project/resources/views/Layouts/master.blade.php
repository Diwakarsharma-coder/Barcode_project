<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    @include('Layouts.head')
</head>
<body>
        @yield('page')


    @include('Layouts.foot')
</body>
</html>
