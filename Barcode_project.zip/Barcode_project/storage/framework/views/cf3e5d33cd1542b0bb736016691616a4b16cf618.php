 

<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
        
       


    <div class="container d-flex align-items-center justify-content-center mt-5">

        <div>
            <h4>Edit Profile Bar Code</h4>    
            <?php echo DNS2D::getBarcodeHTML( route('edit', ['id'=>Auth::user()->id]), 'QRCODE'); ?>

            
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\graycyan\resources\views/editbarcode.blade.php ENDPATH**/ ?>