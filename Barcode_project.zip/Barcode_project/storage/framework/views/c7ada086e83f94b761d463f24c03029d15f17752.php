 

<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .error {
      color: red;
   }
</style>
 <div class="container">
        <h2>Registration Form</h2>
         <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    
        <form method="post" action="<?php echo e(route('updateData',['id'=>$data->id])); ?>"  id="registerForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstName">First Name*</label>
                <input type="text" class="form-control" id="firstName"  value="<?php echo e($data->first_name); ?>" name="firstName"  placeholder="Enter First Name">
                <span></span>
                <?php if($errors->has('firstName')): ?>
                        <div class="error"><?php echo e($errors->first('firstName')); ?></div>
                <?php endif; ?>
                          
            </div>
            <div class="form-group">
                <label for="middleName">Middle Name</label>
                <input type="text" class="form-control" id="middleName"  value="<?php echo e($data->middle_name); ?>" name="middleName" placeholder="Enter Middle Name">
            </div>
            <div class="form-group">
                <label for="lastName">Last Name*</label>
                <input type="text" class="form-control" id="lastName"  value="<?php echo e($data->last_name); ?>" name="lastName" placeholder="Enter Last Name">
                <span></span>
                <?php if($errors->has('lastName')): ?>
                        <div class="error"><?php echo e($errors->first('lastName')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="email">Email*</label>
                <input type="email" class="form-control" id="email"  value="<?php echo e($data->email); ?>" name="email" placeholder="Enter Email">
                <span></span>
                 <?php if($errors->has('email')): ?>
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="mobileNumber">Mobile Number*</label>
                <input type="tel" class="form-control" maxlength="12" onkeypress="return onlyNumberKey(event)" id="mobileNumber"  value="<?php echo e($data->mobile_number); ?>" name="mobileNumber" placeholder="Enter Mobile Number">
                <span></span>
                 <?php if($errors->has('mobileNumber')): ?>
                        <div class="error"><?php echo e($errors->first('mobileNumber')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="address">Address*</label>
                <textarea class="form-control" id="address"  name="address" placeholder="Enter Address"><?php echo e($data->address); ?></textarea>
                <span></span>
                 <?php if($errors->has('address')): ?>
                        <div class="error"><?php echo e($errors->first('address')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control-file" id="image" name="image[]" multiple accept="image/*">
                 <?php if($errors->has('image')): ?>
                        <div class="error"><?php echo e($errors->first('image')); ?></div>
                <?php endif; ?>
                <div class="gallery"></div>
                <input type="hidden" name="old_image" value="<?php echo e($data->image); ?>">
                <?php
                    $array = explode("|", $data->image);
                    ?>
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <img width="200px" class="old_imageData" style="border: 1px solid #ccc; margin: 5px" height="200px" src="<?php echo e(asset('uploads/'.$val)); ?>">
                        
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(route('list')); ?>" class="btn btn-info">Back</a>
        </form>
    </div>
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
 
<style>
    img{
        border: 1px solid #ccc;
        margin: 5px;
    }
</style>
 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>

       

        // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;

            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {
                    $($.parseHTML('<img width="200px" height="200px" style="border:1px solde red; ">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#image').on('change', function() {
        $('.old_imageData').css('display','none');
      
        imagesPreview(this, 'div.gallery');
    });


        function onlyNumberKey(evt) {
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }
            // jQuery.validator.setDefaults({
            //   debug: true,
            //   success: "valid"
            // });

      

        $("#registerForm").validate({
            ignore: [],
            rules: {
                firstName: "required",
                lastName: "required",
                password:{
                        required:true,
                        minlength:8,
                       
                        },
                confirmPassword:{
                        minlength:8,
                        equalTo :'#password'
                        },
                 mobileNumber: {
                      required: true,
                      maxlength: 12
                    },
                address: "required",
                email: {
                    required: true,
                    email: true
                },
                // phone: "required",
                image: {
                    required: true,
                    accept: "jpg,png,jpeg,gif,pdf",
                    filesize: 2024000
                },
               
            },
            messages: {
                firstName: "Please enter first name",
                lastName: "Please enter last name",
                password: "Please enter strong password 'like: kfDes@865' ",
                confirmPassword: "Please enter confirm Password ",
                mobileNumber: {
                    required: "Please enter mobile",
                    maxlength: "Please enter valid mobile number"
                },
                address: "Please enter address ",
                email: {
                    required: "Please enter email",
                    email: "Please enter valid email"
                },
                // phone: "Please enter phone",
                image: {
                    required: "Please select image",
                    accept: "Only image type jpg/png/jpeg is allowed"
                },
               

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }

        });


        function checkPasswordStrength() {
            var number = /([0-9])/;
            var alphabets = /([a-zA-Z])/;
            var special_characters = /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/;
            var password = $('#password').val().trim();
            if (password.length < 6) {
                $('#password-strength-status').removeClass();
                $('#password-strength-status').addClass('weak-password');
                $('#password-strength-status').html("Weak (should be atleast 8 characters.)");
            } else {
                if (password.match(number) && password.match(alphabets) && password.match(special_characters)) {
                    $('#password-strength-status').removeClass();
                    $('#password-strength-status').addClass('strong-password');
                    $('#password-strength-status').html(' ');
                }
                else {
                    $('#password-strength-status').removeClass();
                    $('#password-strength-status').addClass('medium-password');
                    $('#password-strength-status').html("Medium (should include alphabets, numbers and special characters.)");
                }
            }
        }
            
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/edit.blade.php ENDPATH**/ ?>