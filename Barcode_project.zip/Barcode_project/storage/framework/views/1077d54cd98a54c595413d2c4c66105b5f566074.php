<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <?php echo $__env->make('Layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
        <?php echo $__env->yieldContent('page'); ?>


    <?php echo $__env->make('Layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\graycyan\resources\views/Layouts/master.blade.php ENDPATH**/ ?>