 

<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<style>
    span{
        color: red !important;
    }
</style>
 <div class="container">
        <h2>User Derails</h2>
  
                    
        <form method="post"  id="registerForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstName">First Name</label>
                <input type="text" class="form-control" id="firstName"  value="<?php echo e($data->first_name); ?>" name="firstName"  disabled>
            </div>
            <div class="form-group">
                <label for="middleName">Middle Name</label>
                <input type="text" class="form-control" id="middleName"  value="<?php echo e($data->middle_name); ?>" name="middleName" disabled >
            </div>
            <div class="form-group">
                <label for="lastName">Last Name</label>
                <input type="text" class="form-control" id="lastName"  value="<?php echo e($data->last_name); ?>" name="lastName" disabled >
              
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email"  value="<?php echo e($data->email); ?>" name="email" disabled >
               
            </div>
           
            <div class="form-group">
                <label for="mobileNumber">Mobile Number</label>
                <input type="tel" class="form-control"  onkeypress="return onlyNumberKey(event)" id="mobileNumber"  value="<?php echo e($data->mobile_number); ?>" name="mobileNumber" disabled>
               
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea class="form-control" id="address"   name="address" disabled ><?php echo e($data->address); ?></textarea>
                
            </div>
            <div class="form-group">
                <?php
                    $array = explode("|", $data->image);
                    ?>
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img width="200px" style="border: 1px solid #ccc; margin: 5px" height="200px" src="<?php echo e(asset('uploads/'.$val)); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
            </div>
            <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary">Back</a>
        </form>
    </div>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/view.blade.php ENDPATH**/ ?>