 

<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<style>
    span{
        color: red !important;
    }
</style>
 <div class="container">
        <h2>User Derails</h2>
  
                    
        <form method="post"  id="registerForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstName">First Name</label>
                <input type="text" class="form-control" id="firstName"  value="<?php echo e($data->first_name); ?>" name="firstName"  disabled>
            </div>
          
            <div class="form-group">
                <label for="lastName">Last Name</label>
                <input type="text" class="form-control" id="lastName"  value="<?php echo e($data->last_name); ?>" name="lastName" disabled >
              
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email"  value="<?php echo e($data->email); ?>" name="email" disabled >
               
            </div>
           
            
            <div class="form-group">
                                 
                        <img width="200px" style="border: 1px solid #ccc; margin: 5px" height="200px" src="<?php echo e(asset('uploads/'.$data->image)); ?>">
                   
                   
            </div>
            <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary">Back</a>
        </form>
    </div>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\graycyan\resources\views/view.blade.php ENDPATH**/ ?>