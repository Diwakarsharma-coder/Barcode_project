 

<?php $__env->startSection('title','Edit Profile'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .error {
      color: red;
   }
</style>
 <div class="container">
        <h2>Registration Form</h2>
         <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    
        <form method="post"   id="registerForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstName">First Name*</label>
                <input type="text" class="form-control" id="firstName"  value="<?php echo e($data->first_name); ?>" name="firstName"  placeholder="Enter First Name">
                <span></span>
                <?php if($errors->has('firstName')): ?>
                        <div class="error"><?php echo e($errors->first('firstName')); ?></div>
                <?php endif; ?>
                          
            </div>
            
            <div class="form-group">
                <label for="lastName">Last Name*</label>
                <input type="text" class="form-control" id="lastName"  value="<?php echo e($data->last_name); ?>" name="lastName" placeholder="Enter Last Name">
                <span></span>
                <?php if($errors->has('lastName')): ?>
                        <div class="error"><?php echo e($errors->first('lastName')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="email">Email*</label>
                <input type="email" class="form-control" id="email"  value="<?php echo e($data->email); ?>" name="email" disabled placeholder="Enter Email">
                <span></span>
                 <?php if($errors->has('email')): ?>
                        <div class="error"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
            </div>
            
          
            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control-file" id="image" name="image"  accept="image/*">
                 <?php if($errors->has('image')): ?>
                        <div class="error"><?php echo e($errors->first('image')); ?></div>
                 <?php endif; ?>

               
            </div>
            <div class="form-group">
                        <input type="hidden" name="old_image" value="<?php echo e($data->image); ?>">        
                        <img width="200px" style="border: 1px solid #ccc; margin: 5px" height="200px" src="<?php echo e(asset('uploads/'.$data->image)); ?>">
                   
                   
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-info">Back</a>
        </form>
    </div>
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
 
 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>

       

        $("#registerForm").validate({
            ignore: [],
            rules: {
                firstName: "required",
                lastName: "required",
                email: {
                    required: true,
                    email: true
                },
                // phone: "required",
                image: {
                    required: false,
                    accept:"jpg,png,jpeg,gif"
                    
                },
               
            },
            messages: {
                firstName: "Please enter first name",
                lastName: "Please enter last name",
                
                email: {
                    required: "Please enter email",
                    email: "Please enter valid email"
                },
                
                image: {
                    required: "Please select image",
                    accept: "Only image type jpg/png/jpeg is allowed"
                },

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function (form) {
               let myform = document.getElementById("registerForm");
                 let fd = new FormData(myform );

                 $.ajax({
                   url:"<?php echo e(route('updateData',['id'=>$data->id])); ?>",
                   type:'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                   data: fd,
                    cache: false,
                    processData: false,
                    contentType: false,
                   success:function(data){
                        console.log(data)
                        if(data.success)
                        {
                            window.location = "<?php echo e(route('dashboard')); ?>";
                        }
                    
                   }

                }); 
    
            }


        });


            
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\graycyan\resources\views/edit.blade.php ENDPATH**/ ?>