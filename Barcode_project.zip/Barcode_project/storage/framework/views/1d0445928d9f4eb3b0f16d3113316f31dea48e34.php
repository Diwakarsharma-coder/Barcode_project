 

<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<style>
    span{
        color: red !important;
    }
</style>
 <div class="container">
        <h2>Two Factor Authentication</h2>
         <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    
                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <span><?php echo e($error); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <form method="post" action="<?php echo e(route('2fa_auth')); ?>"  id="verifyForm">
            <?php echo csrf_field(); ?>
           
           <p>Hint : <?php echo e($rand); ?></p>
           <div class="form-group">
                <label for="code_verify">Verify Code*</label>
                    <input type="text" class="form-control"  maxlength="6"  id="code_verify"  onkeypress="return onlyNumberKey(event)" name="code_verify" placeholder="Enter code verify">
                     

            </div>
            <input type="hidden" name="email" value="<?php echo e($email); ?>">
            <input type="hidden" name="password" value="<?php echo e($password); ?>">
            
            
            <button type="submit" id="submit" class="btn btn-primary">Submit</button>
        </form>
        <p style="color: red;"> <strong>NOTE:- </strong> we can use twilio account for two-factor authentication and send OTP via SMS to a registered mobile number. and we can verify this account with OTP.</p>
    </div>




 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
 
 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>

        function onlyNumberKey(evt) {
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }
           
      

        $("#verifyForm").validate({
            ignore: [],
            rules: {
                code_verify: "required",
                
            },
            messages: {
                code_verify: "Please enter verify code",
               

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            },


        });




        function data(){
             var form = $("#verifyForm");
               // $.ajaxSetup({
               //  headers: {
               //  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               //  }
               //  });

             

                $.ajax({
                    url: "<?php echo e(route('2fa_auth')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data:$('#verifyForm').serialize(),
                    success: function(result) {
                        alert(result);
                            consol.log(result);

                    }
                });
        }
           

        

       
    </script>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/2fa.blade.php ENDPATH**/ ?>