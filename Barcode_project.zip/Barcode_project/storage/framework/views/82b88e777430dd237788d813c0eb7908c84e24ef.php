 

<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .error {
      color: red;
   }
</style>

 <div class="container">
        <h2>Login Form</h2>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" role="alert">
                    <span><?php echo e($message); ?></span>
                </div>
            <?php endif; ?>
                    
                    <div id="loginError">
                        
                    </div>
               



                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <span><?php echo e($error); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <form   method="POST"  enctype="multipart/form-data"  id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">User Name*</label>
                <input type="text" class="form-control" id="email"  value="<?php echo e(old('email')); ?>" name="email"  placeholder="Enter First Name">
                <span></span>
               
                          
            </div>
           
            <div class="form-group">
                <label for="password">Password*</label>
                <input type="password" class="form-control"  onkeyup="checkPasswordStrength();" id="password"  value="<?php echo e(old('password')); ?>" name="password" placeholder="Enter Password">
                <span id="password-strength-status"></span>
                
            </div>
           
            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>


    


 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>


        $("#loginForm").validate({
           ignore: [],
            rules: {
                email: "required",
                
                password:{
                        required:true,
                        },
                
               
            },
            messages: {
                email: "Please enter user name",
                 password: "Please enter passsword ",

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            },
             submitHandler: function (form) {
                let myform = document.getElementById("loginForm");
                let fd = new FormData(myform );

                 $.ajax({
                   url:"<?php echo e(route('Datalogin')); ?>",
                   type:'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                   data: fd,
                    cache: false,
                    processData: false,
                    contentType: false,
                   success:function(data){
                       
                        if(data.success)
                        {
                            window.location = "<?php echo e(route('editProfile')); ?>";
                        }
                        else
                        {
                            var error = '<div class="alert alert-danger" role="alert">'+
                                '<span>Oppes! You have entered invalid credentials</span>'+
                            '</div>'
                                $('#loginError').html(error);
                        }

                    
                   }

                }); 
    
            }

        });


       
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\graycyan\resources\views/login.blade.php ENDPATH**/ ?>