<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

   

<div class="container"> 
    <div class="row">
        <div class="col-lg-12 col-md-6 col-sm-4">
             <h1>Welcome</h1>

        </div>
        
    </div>
  </div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/welcome.blade.php ENDPATH**/ ?>