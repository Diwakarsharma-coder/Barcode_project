
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

   

<div class="container"> 
    <div class="row">
        <div class="col-lg-12 col-md-6 col-sm-4">
             <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    
            <table class="table" id="UserTable">
              <thead>
                <tr class="table-dark">
                  <th scope="col">#</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Mobile Number</th>
                  <th scope="col">Action</th>
             
                </tr>
              </thead>
              <tbody id="fabricatorTable">
                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"><?php echo e($value->id); ?></th>
                      <td><?php echo e($value->first_name); ?></td>
                      <td><?php echo e($value->last_name); ?></td>
                      <td><?php echo e($value->email); ?></td>
                      <td><?php echo e($value->mobile_number); ?></td>
                      <td>
                          <a href="<?php echo e(route('view', ['id'=>$value->id] )); ?>" title="View"><i class="fa-solid fa-eye"></i></a> |
                          
                          <a href="<?php echo e(route('edit', ['id'=>$value->id] )); ?>" title="Edit"><i class="fa-solid fa-pen-to-square"></i></a> | 

                          <a href="<?php echo e(route('delete', ['id'=>$value->id] )); ?>" onclick="return confirm('Are you sure?')" title="Delete"><i class="fa-sharp fa-solid fa-trash"></i></a>

                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                
               
              </tbody>
            </table>

        </div>
        
    </div>
  </div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/list.blade.php ENDPATH**/ ?>