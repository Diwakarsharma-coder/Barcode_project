 

<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .error {
      color: red;
   }
</style>

 <div class="container">
        <h2>Login Form</h2>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" role="alert">
                    <span><?php echo e($message); ?></span>
                </div>
            <?php endif; ?>


                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <span><?php echo e($error); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <form method="post" action="<?php echo e(route('login')); ?>"  id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email">User Name*</label>
                <input type="text" class="form-control" id="email"  value="<?php echo e(old('email')); ?>" name="email"  placeholder="Enter First Name">
                <span></span>
               
                          
            </div>
           
            <div class="form-group">
                <label for="password">Password*</label>
                <input type="password" class="form-control"  onkeyup="checkPasswordStrength();" id="password"  value="<?php echo e(old('password')); ?>" name="password" placeholder="Enter Password">
                <span id="password-strength-status"></span>
                
            </div>
           
            
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>


    


 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
 
<style>
    img{
        border: 1px solid #ccc;
        margin: 5px;
    }
</style>
 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>

        function onlyNumberKey(evt) {
            var ASCIICode = (evt.which) ? evt.which : evt.keyCode
            if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                return false;
            return true;
        }
           
      

        $("#loginForm").validate({
            ignore: [],
            rules: {
                email: "required",
                
                password:{
                        required:true,
                        },
                
               
            },
            messages: {
                email: "Please enter user name",
                 password: "Please enter passsword ",
               
               

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }

        });


       
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\graycyan\resources\views/login.blade.php ENDPATH**/ ?>