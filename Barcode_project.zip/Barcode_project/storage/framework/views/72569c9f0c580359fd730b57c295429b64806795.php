 

<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .error {
      color: red;
   }
</style>
 <div class="container">
        <h2>Registration Form</h2>
         <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <p id="allError"></p>

        <form  method="POST"  id="registerForm" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="firstName">First Name*</label>
                <input type="text" class="form-control" id="firstName"  value="<?php echo e(old('firstName')); ?>" name="firstName"  placeholder="Enter First Name">
                <span></span>
                <?php if($errors->has('firstName')): ?>
                        <div class="error"><?php echo e($errors->first('firstName')); ?></div>
                <?php endif; ?>
                          
            </div>
            
            <div class="form-group">
                <label for="lastName">Last Name*</label>
                <input type="text" class="form-control" id="lastName"  value="<?php echo e(old('lastName')); ?>" name="lastName" placeholder="Enter Last Name">
                <span></span>
                <?php if($errors->has('lastName')): ?>
                        <div class="error"><?php echo e($errors->first('lastName')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="email">Email*</label>
                <input type="email" class="form-control" id="email"  value="<?php echo e(old('email')); ?>" name="email" placeholder="Enter Email">
                <span></span>
                 <?php if($errors->has('email')): ?>
                        <div class="error" id="email_error"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="password">Password*</label>
                <input type="password" class="form-control"   id="password"  value="<?php echo e(old('password')); ?>" name="password" placeholder="Enter Password">
                <span id="password-strength-status"></span>
                 <?php if($errors->has('password')): ?>
                        <div class="error"><?php echo e($errors->first('password')); ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm Password*</label>
                <input type="password" class="form-control" id="confirmPassword"  value="<?php echo e(old('confirmPassword')); ?>" name="confirmPassword" placeholder="Enter Password Again">
                <span></span>
                 <?php if($errors->has('confirmPassword')): ?>
                        <div class="error"><?php echo e($errors->first('confirmPassword')); ?></div>
                <?php endif; ?>
            </div>
           
            
           
            <button type="submit" class="btn btn-primary">Submit</button>
              <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary">Back</a>
        </form>
    </div>
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
      <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

 <script src="http://jqueryvalidation.org/files/dist/jquery.validate.min.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

      <script>

          // $.ajaxSetup({
          //       headers: {
          //           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          //       }
          //   });

        $("#registerForm").validate({
            ignore: [],
            rules: {
                firstName: "required",
                lastName: "required",
                password:{
                        required:true,
                        minlength:8,
                       
                        },
                confirmPassword:{
                        required:true,
                        minlength:8,
                        equalTo :'#password'
                        },
              
                // email: {
                //     required: true,
                //     email: true
                // },
              
               
            },
            messages: {
                firstName: "Please enter first name",
                lastName: "Please enter last name",
                password: "Please enter password",
                confirmPassword: "Please enter confirm password ",
              
                // email: {
                //     required: "Please enter email",
                //     email: "Please enter valid email"
                // },
               
               

            },
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            },
            submitHandler: function (form) {
               let myform = document.getElementById("registerForm");
                 let fd = new FormData(myform );

                 $.ajax({
                   url:"<?php echo e(route('registerData')); ?>",
                   type:'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                   data: fd,
                    cache: false,
                    processData: false,
                    contentType: false,
                   success:function(data){
                        console.log(data)
                        if(data.success)
                        {
                            window.location = "<?php echo e(route('dashboard')); ?>";
                        }
                    
                   }

                }); 
    
            }

        });


        // action="<?php echo e(route('registerData')); ?>"
            
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\New folder\graycyan\resources\views/register.blade.php ENDPATH**/ ?>